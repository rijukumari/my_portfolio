import { useEffect, useState } from 'react'

export default function useDarkMode() {
  const [enabled, setEnabled] = useState<boolean>(() => {
    return localStorage.getItem('ms_dark') === '1'
  })

  useEffect(() => {
    const root = window.document.documentElement
    if (enabled) root.classList.add('dark')
    else root.classList.remove('dark')
    localStorage.setItem('ms_dark', enabled ? '1' : '0')
  }, [enabled])

  return { enabled, setEnabled }
}
