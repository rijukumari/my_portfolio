import React, { createContext, useContext, useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

type Role = 'admin' | 'teacher' | 'student' | 'parent' | 'employee'

interface User {
  name: string
  email: string
  role: Role
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const DUMMY_USERS: User[] = [
  { name: 'Admin User', email: 'admin@example.com', role: 'admin' },
  { name: 'Teacher Tom', email: 'teacher@example.com', role: 'teacher' },
  { name: 'Student Sam', email: 'student@example.com', role: 'student' },
]

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const navigate = useNavigate()

  useEffect(() => {
    const raw = localStorage.getItem('ms_user')
    if (raw) setUser(JSON.parse(raw))
  }, [])

  const login = async (email: string, password: string) => {
    // fake auth: password must be 'password' for demo
    const found = DUMMY_USERS.find((u) => u.email === email)
    if (found && password === 'password') {
      setUser(found)
      localStorage.setItem('ms_user', JSON.stringify(found))
      localStorage.setItem('ms_token', 'FAKE_TOKEN')
      return true
    }
    return false
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('ms_user')
    localStorage.removeItem('ms_token')
    navigate('/login')
  }

  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
