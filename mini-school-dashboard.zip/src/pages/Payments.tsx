import React from 'react'
import Sidebar from '../components/layout/Sidebar'
import Topbar from '../components/layout/Topbar'

const Payments: React.FC = () => {
  const payments = [
    { id: 'p1', student: 'Sam', amount: 20000, status: 'Paid' },
    { id: 'p2', student: 'Jill', amount: 18000, status: 'Pending' },
  ]
  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 min-h-screen">
        <Topbar />
        <main className="p-6">
          <h2 className="text-2xl font-semibold mb-4">Fees / Payments</h2>
          <div className="grid gap-3">
            {payments.map(p => (
              <div key={p.id} className="p-3 bg-white dark:bg-gray-800 rounded shadow flex justify-between">
                <div>
                  <div className="font-semibold">{p.student}</div>
                  <div className="text-sm text-gray-500">{p.status}</div>
                </div>
                <div>₹{p.amount}</div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}

export default Payments
