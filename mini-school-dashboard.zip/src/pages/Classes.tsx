import React from 'react'
import Sidebar from '../components/layout/Sidebar'
import Topbar from '../components/layout/Topbar'

const Classes: React.FC = () => {
  const classes = [
    { id: 'c1', name: '10A' },
    { id: 'c2', name: '9B' },
  ]
  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 min-h-screen">
        <Topbar />
        <main className="p-6">
          <h2 className="text-2xl font-semibold mb-4">Classes</h2>
          <div className="grid gap-3">
            {classes.map(c => (
              <div key={c.id} className="p-3 bg-white dark:bg-gray-800 rounded shadow">{c.name}</div>
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}

export default Classes
