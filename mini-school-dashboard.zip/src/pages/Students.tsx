import React, { useState } from 'react'
import Sidebar from '../components/layout/Sidebar'
import Topbar from '../components/layout/Topbar'

type Student = { id: string; name: string; className: string; contact: string; fees: number }

const initial: Student[] = [
  { id: 's1', name: 'Sam', className: '10A', contact: '9876543210', fees: 20000 },
  { id: 's2', name: 'Jill', className: '9B', contact: '9123456780', fees: 18000 },
]

const Students: React.FC = () => {
  const [list, setList] = useState<Student[]>(() => {
    const raw = localStorage.getItem('ms_students')
    return raw ? JSON.parse(raw) : initial
  })
  const [name, setName] = useState('')

  const add = () => {
    if (!name.trim()) return
    const s = { id: Date.now().toString(), name, className: 'N/A', contact: '', fees: 0 }
    const next = [s, ...list]
    setList(next)
    localStorage.setItem('ms_students', JSON.stringify(next))
    setName('')
  }

  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 min-h-screen">
        <Topbar />
        <main className="p-6">
          <h2 className="text-2xl font-semibold mb-4">Students</h2>

          <div className="mb-4 flex gap-2">
            <input value={name} onChange={e=>setName(e.target.value)} className="px-3 py-2 border rounded flex-1" placeholder="New student name" />
            <button onClick={add} className="px-4 py-2 bg-indigo-600 text-white rounded">Add</button>
          </div>

          <div className="grid gap-3">
            {list.map(s => (
              <div key={s.id} className="p-3 bg-white dark:bg-gray-800 rounded shadow flex justify-between">
                <div>
                  <div className="font-semibold">{s.name}</div>
                  <div className="text-sm text-gray-500">{s.className} • {s.contact}</div>
                </div>
                <div className="text-sm">Fees: ₹{s.fees}</div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}

export default Students
