import React from 'react'
import Sidebar from '../components/layout/Sidebar'
import Topbar from '../components/layout/Topbar'

const Employees: React.FC = () => {
  const employees = [
    { id: 'e1', name: 'Alice', role: 'Accountant' },
    { id: 'e2', name: 'Bob', role: 'Clerk' },
  ]
  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 min-h-screen">
        <Topbar />
        <main className="p-6">
          <h2 className="text-2xl font-semibold mb-4">Employees</h2>
          <div className="grid gap-3">
            {employees.map(e => (
              <div key={e.id} className="p-3 bg-white dark:bg-gray-800 rounded shadow flex justify-between">
                <div>
                  <div className="font-semibold">{e.name}</div>
                  <div className="text-sm text-gray-500">{e.role}</div>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}

export default Employees
