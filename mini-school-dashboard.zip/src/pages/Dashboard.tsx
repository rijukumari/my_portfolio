import React from 'react'
import Sidebar from '../components/layout/Sidebar'
import Topbar from '../components/layout/Topbar'
import ErrorBoundary from '../components/ui/ErrorBoundary'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

const sample = [
  { name: 'Jan', fees: 4000 },
  { name: 'Feb', fees: 3000 },
  { name: 'Mar', fees: 5000 },
  { name: 'Apr', fees: 4000 },
  { name: 'May', fees: 6000 },
]

const Dashboard: React.FC = () => {
  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 min-h-screen">
        <Topbar />
        <main className="p-6">
          <h2 className="text-2xl font-semibold mb-4">Dashboard</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="p-4 bg-white dark:bg-gray-800 rounded shadow">Total Students: 420</div>
            <div className="p-4 bg-white dark:bg-gray-800 rounded shadow">Active Fees: ₹1,20,000</div>
            <div className="p-4 bg-white dark:bg-gray-800 rounded shadow">Attendance Avg: 92%</div>
          </div>

          <div className="p-4 bg-white dark:bg-gray-800 rounded shadow h-64">
            <ErrorBoundary>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sample}>
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="fees" stroke="#8884d8" />
                </LineChart>
              </ResponsiveContainer>
            </ErrorBoundary>
          </div>
        </main>
      </div>
    </div>
  )
}

export default Dashboard
