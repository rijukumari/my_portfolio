import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const Login: React.FC = () => {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const ok = await login(email.trim(), password)
    if (ok) navigate('/')
    else setErr('Invalid credentials — use email from README and password `password`')
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <form onSubmit={onSubmit} className="w-full max-w-md bg-white dark:bg-gray-800 p-6 rounded shadow">
        <h2 className="text-xl font-semibold mb-4">Login</h2>
        {err && <div className="text-red-500 mb-2">{err}</div>}
        <label className="block mb-2">
          <div className="text-sm mb-1">Email</div>
          <input value={email} onChange={e => setEmail(e.target.value)} className="w-full px-3 py-2 border rounded bg-transparent" />
        </label>
        <label className="block mb-4">
          <div className="text-sm mb-1">Password</div>
          <input value={password} onChange={e => setPassword(e.target.value)} type="password" className="w-full px-3 py-2 border rounded bg-transparent" />
        </label>
        <button type="submit" className="w-full py-2 bg-indigo-600 text-white rounded">Login</button>
        <div className="mt-3 text-sm text-gray-500">Demo users: admin@example.com, teacher@example.com, student@example.com (password = password)</div>
      </form>
    </div>
  )
}

export default Login
