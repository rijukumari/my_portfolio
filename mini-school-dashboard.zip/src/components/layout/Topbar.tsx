import React from 'react'
import { useAuth } from '../../context/AuthContext'
import useDarkMode from '../../hooks/useDarkMode'

const Topbar: React.FC = () => {
  const { user, logout } = useAuth()
  const { enabled, setEnabled } = useDarkMode()

  return (
    <div className="flex items-center justify-between px-4 py-3 bg-white dark:bg-gray-800 shadow-sm">
      <div className="flex items-center gap-4">
        <button className="md:hidden">☰</button>
        <h1 className="text-lg font-semibold">Mini Dashboard</h1>
      </div>

      <div className="flex items-center gap-4">
        <button
          onClick={() => setEnabled(!enabled)}
          className="px-3 py-1 rounded border"
        >
          {enabled ? 'Light' : 'Dark'}
        </button>

        <div className="flex items-center gap-2">
          <div className="text-sm">{user?.name}</div>
          <button onClick={logout} className="px-3 py-1 bg-red-500 text-white rounded">
            Logout
          </button>
        </div>
      </div>
    </div>
  )
}

export default Topbar
