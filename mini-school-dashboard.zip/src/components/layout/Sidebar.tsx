import React from 'react'
import { NavLink } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

const Sidebar: React.FC = () => {
  const { user } = useAuth()

  const links = [
    { to: '/', label: 'Dashboard', roles: ['admin', 'teacher', 'student', 'employee', 'parent'] },
    { to: '/students', label: 'Students', roles: ['admin', 'teacher'] },
    { to: '/employees', label: 'Employees', roles: ['admin'] },
    { to: '/classes', label: 'Classes', roles: ['admin', 'teacher'] },
    { to: '/payments', label: 'Fees/Payments', roles: ['admin'] },
  ]

  return (
    <aside className="w-56 bg-white dark:bg-gray-900 border-r min-h-screen p-4">
      <div className="mb-6">
        <div className="font-bold text-lg">MS Dashboard</div>
        <div className="text-sm text-gray-500">{user?.role}</div>
      </div>

      <nav className="flex flex-col gap-2">
        {links
          .filter((l) => l.roles.includes(user?.role ?? ''))
          .map((l) => (
            <NavLink key={l.to} to={l.to} className={({ isActive }) =>
                `px-3 py-2 rounded ${isActive ? 'bg-indigo-500 text-white' : 'text-gray-700 dark:text-gray-200'}`
              }>
              {l.label}
            </NavLink>
        ))}
      </nav>
    </aside>
  )
}

export default Sidebar
