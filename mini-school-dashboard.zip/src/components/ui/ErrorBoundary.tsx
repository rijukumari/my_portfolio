import React from 'react'

class ErrorBoundary extends React.Component<{children: React.ReactNode}, {hasError: boolean}> {
  state = { hasError: false }
  static getDerivedStateFromError() { return { hasError: true } }
  componentDidCatch(error: any) { console.error(error) }
  render() {
    if (this.state.hasError) return <div className="p-8">Something went wrong</div>
    return this.props.children
  }
}

export default ErrorBoundary
