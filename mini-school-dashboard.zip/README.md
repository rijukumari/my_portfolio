# Mini School/Company Management Dashboard

This is a Vite + React + TypeScript + Tailwind skeleton for the Mini School/Company Management Dashboard project.

## Quick start

1. Install:

```bash
npm install
```

2. Run dev server:

```bash
npm run dev
```

3. Demo users:

- admin@example.com (password: password)
- teacher@example.com (password: password)
- student@example.com (password: password)

Notes: This project uses localStorage for demo authentication and simple demo data. Replace with real API for production.
